import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { io } from 'socket.io-client';
import { Globe2, MapPin, Smartphone, MessageCircle, BriefcaseBusiness, House, CarFront, Wallet, ShoppingBag, Plane, Users, Newspaper, LogOut, Menu, X, Send, ArrowDownToLine, ArrowUpFromLine, Sparkles, ShieldCheck, Gamepad2, Building2, Compass, Heart, Bell, Search, ChevronRight, CreditCard, UserRound, CircleDollarSign } from 'lucide-react';
import './styles.css';
import World3D from './World3D.jsx';

// Set VITE_API_URL in your frontend build environment to your deployed backend URL,
// for example: https://your-backend-name.onrender.com (do not append /api).
const API_BASE = (import.meta.env.VITE_API_URL || '').trim().replace(/\/+$/, '');
const API = `${API_BASE}/api`;

const FALLBACK_WORLD = {
  states: {
    Nigeria: [
      'Abia', 'Adamawa', 'Akwa Ibom', 'Anambra', 'Bauchi', 'Bayelsa',
      'Benue', 'Borno', 'Cross River', 'Delta', 'Ebonyi', 'Edo', 'Ekiti',
      'Enugu', 'FCT', 'Gombe', 'Imo', 'Jigawa', 'Kaduna', 'Kano', 'Katsina',
      'Kebbi', 'Kogi', 'Kwara', 'Lagos', 'Nasarawa', 'Niger', 'Ogun', 'Ondo',
      'Osun', 'Oyo', 'Plateau', 'Rivers', 'Sokoto', 'Taraba', 'Yobe', 'Zamfara'
    ],
    USA: [
      'Alabama', 'Alaska', 'Arizona', 'California', 'Colorado', 'Florida',
      'Georgia', 'Illinois', 'Maryland', 'Massachusetts', 'Michigan', 'New Jersey',
      'New York', 'North Carolina', 'Ohio', 'Pennsylvania', 'Texas', 'Virginia',
      'Washington'
    ]
  },
  cities: {
    Nigeria: [
      'Lagos', 'Abuja', 'Kano', 'Ibadan', 'Port Harcourt', 'Benin City',
      'Enugu', 'Abeokuta'
    ],
    USA: [
      'New York City', 'Los Angeles', 'Chicago', 'Houston', 'Miami', 'Atlanta',
      'Boston', 'Seattle', 'Dallas', 'Washington, D.C.'
    ]
  }
};

const money = (n, country) => new Intl.NumberFormat(country === 'Nigeria' ? 'en-NG' : 'en-US', { style:'currency', currency: country === 'Nigeria' ? 'NGN':'USD', maximumFractionDigits:0 }).format(n);

async function request(path, token, body) {
  let response;
  try {
    response = await fetch(`${API}${path}`, {
      method: body !== undefined ? 'POST' : 'GET',
      headers: {
        ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
        ...(token ? { Authorization: `Bearer ${token}` } : {})
      },
      ...(body !== undefined ? { body: JSON.stringify(body) } : {})
    });
  } catch (error) {
    throw new Error(`Cannot reach the backend. Check VITE_API_URL and backend availability. ${error.message}`);
  }

  const contentType = response.headers.get('content-type') || '';
  const raw = await response.text();
  let data = {};
  if (raw && contentType.includes('application/json')) {
    try { data = JSON.parse(raw); } catch { throw new Error('The backend returned invalid JSON. Check the backend logs.'); }
  } else if (raw) {
    throw new Error(`Backend returned a non-JSON response (HTTP ${response.status}). Check VITE_API_URL and API routes.`);
  }

  if (!response.ok) throw new Error(data.error || `Request failed (HTTP ${response.status})`);
  return data;
}
const Icon = ({name,size=19}) => { const map={home:House,phone:Smartphone,chat:MessageCircle,work:BriefcaseBusiness,car:CarFront,bank:Wallet,shop:ShoppingBag,travel:Plane,social:Newspaper,people:Users,globe:Globe2,explore:Compass,building:Building2,profile:UserRound,game:Gamepad2}; const C=map[name]||Sparkles; return <C size={size}/>; };

function App(){
 const [token,setToken]=useState(localStorage.getItem('wl-token')||'');
 const [user,setUser]=useState(null), [world,setWorld]=useState(FALLBACK_WORLD);
 const [page,setPage]=useState('home'), [busy,setBusy]=useState(false), [error,setError]=useState(''), [notice,setNotice]=useState('');
 const [authMode,setAuthMode]=useState('register'), [form,setForm]=useState({username:'',email:'',password:'',country:'Nigeria',state:'Lagos',city:'Lagos'});
 const [messages,setMessages]=useState([]), [message,setMessage]=useState(''), [posts,setPosts]=useState([]), [postText,setPostText]=useState('');
 const [job,setJob]=useState('Delivery Rider'), [amount,setAmount]=useState('1000'), [travelTo,setTravelTo]=useState('USA'), [mobileMenu,setMobileMenu]=useState(false);
 const [market,setMarket]=useState([]);
 useEffect(() => {
  request('/world').then(data => {
    const hasLocations = data?.states?.Nigeria?.length && data?.states?.USA?.length && data?.cities?.Nigeria?.length && data?.cities?.USA?.length;
    if (hasLocations) {
      setWorld(data);
      setForm(current => ({
        ...current,
        state: data.states[current.country]?.includes(current.state) ? current.state : (data.states[current.country]?.[0] || ''),
        city: data.cities[current.country]?.includes(current.city) ? current.city : (data.cities[current.country]?.[0] || '')
      }));
    } else {
      setWorld(FALLBACK_WORLD);
    }
  }).catch(() => setWorld(FALLBACK_WORLD));

  request('/market').then(data => setMarket(Array.isArray(data.listings) ? data.listings : [])).catch(() => setMarket([]));
}, []);
 useEffect(()=>{if(token) request('/me',token).then(d=>setUser(d.user)).catch(()=>{localStorage.removeItem('wl-token');setToken('');setUser(null);});},[token]);
 useEffect(()=>{if(!token)return;request('/messages',token).then(d=>setMessages(d.messages)).catch(()=>{});request('/feed',token).then(d=>setPosts(d.posts)).catch(()=>{});const socket=io(API_BASE || undefined,{transports:['websocket','polling'],auth:{token}});socket.on('chat:message',m=>setMessages(prev=>prev.some(x=>x.id===m.id)?prev:[...prev,m].slice(-100)));return()=>socket.disconnect();},[token]);
 const call=async fn=>{setBusy(true);setError('');setNotice('');try{await fn()}catch(e){setError(e.message)}finally{setBusy(false)}};
 const sign=()=>call(async()=>{const path=authMode==='register'?'/register':'/login';const payload=authMode==='register'?form:{email:form.email,password:form.password};const d=await request(path,'',payload);localStorage.setItem('wl-token',d.token);setToken(d.token);setUser(d.user);setNotice('Welcome to your new life.');});
 const updateUser=async d=>{if(d.user)setUser(d.user);};
 const sendMessage=()=>call(async()=>{const d=await request('/messages',token,{text:message});setMessages(p=>p.some(x=>x.id===d.message.id)?p:[...p,d.message]);setMessage('');});
 const publish=()=>call(async()=>{const d=await request('/feed',token,{text:postText});setPosts(p=>[d.post,...p]);setPostText('');});
 const work=()=>call(async()=>{const d=await request('/work',token,{job});setUser(d.user);setNotice(`Shift complete! You earned ${money(d.earned,user.country)} in game.`);});
 const bank=action=>call(async()=>{const d=await request('/bank',token,{action,amount});setUser(d.user);setNotice('Your in-game banking transaction is complete.');});
 const buy=item=>call(async()=>{const d=await request('/buy',token,{item});setUser(d.user);setNotice(`${item} purchased successfully.`);});
 const travel=()=>call(async()=>{const d=await request('/travel/quote',token,{destination:travelTo});setNotice(`${d.destination} trip: $${d.priceUSD} USD. ${d.message}`);});
 const nav=[['home','Home'],['game','3D World'],['phone','World Phone'],['chat','Messages'],['social','Social Feed'],['work','Jobs & Career'],['building','Property'],['car','Vehicles'],['bank','Banking'],['shop','Marketplace'],['travel','Travel'],['people','Community']];
 const activeLabel=nav.find(n=>n[0]===page)?.[1]||'Home';
 if(!user)return <div className="authShell"><div className="authVisual"><div className="brand"><Globe2/> WORLD LIFE <b>4K</b></div><div className="heroCopy"><span className="eyebrow">TWO COUNTRIES. ONE WORLD.</span><h1>Your story.<br/><em>Your rules.</em></h1><p>Build a career, find a home, meet people and create your own life across Nigeria and the United States.</p><div className="authPills"><span>🇳🇬 Nigeria</span><span>🇺🇸 United States</span><span><Gamepad2 size={15}/> Life simulation</span></div></div><div className="visualFooter">A new world is waiting for you.</div></div><div className="authPanel"><div className="authCard"><div className="mobileBrand brand"><Globe2/> WORLD LIFE <b>4K</b></div><span className="eyebrow">{authMode==='register'?'START YOUR JOURNEY':'WELCOME BACK'}</span><h2>{authMode==='register'?'Create your character':'Sign in to your world'}</h2><p className="muted">Your world is yours to build.</p><form onSubmit={e=>{e.preventDefault();sign()}}>{authMode==='register'&&<label>Player name<input required maxLength="24" placeholder="Choose a username" value={form.username} onChange={e=>setForm({...form,username:e.target.value})}/></label>}<label>Email address<input type="email" required placeholder="you@example.com" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></label><label>Password<input type="password" required minLength={authMode==='register'?8:1} placeholder={authMode==='register'?'At least 8 characters':'Your password'} value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/></label>{authMode==='register'&&<><label>Starting country<select value={form.country} onChange={e=>{const c=e.target.value;setForm({...form,country:c,state:world.states[c]?.[0]||'',city:world.cities[c]?.[0]||''})}}><option>Nigeria</option><option>USA</option></select></label><div className="formRow"><label>State / territory<select value={form.state} onChange={e=>setForm({...form,state:e.target.value})}>{(world.states[form.country]||[]).map(s=><option key={s}>{s}</option>)}</select></label><label>Starting city<select value={form.city} onChange={e=>setForm({...form,city:e.target.value})}>{(world.cities[form.country]||[]).map(c=><option key={c}>{c}</option>)}</select></label></div></>}<button className="primary full" disabled={busy}>{busy?'Please wait…':authMode==='register'?'Create account':'Sign in'} <ChevronRight size={18}/></button></form>{error&&<div className="alert error">{error}</div>}<p className="switchAuth">{authMode==='register'?'Already have an account?':'New to World Life?'} <button onClick={()=>{setAuthMode(authMode==='register'?'login':'register');setError('')}}>{authMode==='register'?'Sign in':'Create account'}</button></p><div className="security"><ShieldCheck size={16}/> Your password is securely hashed on the server.</div></div></div></div>;
 return <div className="appShell"><aside className={`sidebar ${mobileMenu?'open':''}`}><div className="brand"><Globe2/> WORLD LIFE <b>4K</b><button className="closeMenu" onClick={()=>setMobileMenu(false)}><X/></button></div><div className="serverBadge"><span className="liveDot"/> LIVE WORLD <small>{user.country} server</small></div><div className="playerMini"><div className="avatar">{user.username.slice(0,1).toUpperCase()}</div><div><strong>{user.username}</strong><small>Level {user.level} · {user.city}</small></div><span className="onlineDot"/></div><nav>{nav.map(([id,label])=><button key={id} className={page===id?'selected':''} onClick={()=>{setPage(id);setMobileMenu(false)}}><Icon name={id}/>{label}{id==='chat'&&<span className="navBadge">{messages.length}</span>}</button>)}</nav><div className="sidebarBottom"><div className="serverTip"><Globe2 size={18}/><div><b>One connected world</b><small>Travel between countries</small></div></div><button className="logout" onClick={()=>{request('/logout',token,{}).catch(()=>{});localStorage.removeItem('wl-token');setToken('');setUser(null)}}><LogOut size={17}/> Sign out</button><small className="version">WORLD LIFE 4K · FOUNDATION BUILD</small></div></aside>
 <main className="mainArea"><header className="topbar"><button className="menuButton" onClick={()=>setMobileMenu(true)}><Menu/></button><div><span className="eyebrow">YOUR LIFE, YOUR CHOICES</span><h2>{activeLabel}</h2></div><div className="topActions"><div className="topCash"><Wallet size={17}/><span>{money(user.cash,user.country)}</span></div><button className="iconButton" title="Notifications"><Bell size={19}/></button><div className="topAvatar">{user.username.slice(0,1).toUpperCase()}</div></div></header><section className="content">
 {error&&<div className="alert error">{error}<button onClick={()=>setError('')}>×</button></div>}{notice&&<div className="alert success">{notice}<button onClick={()=>setNotice('')}>×</button></div>}
 {page==='game'&&<World3D username={user.username} city={user.city} country={user.country} token={token}/>}
 {page==='home'&&<><div className="welcomeBanner"><div className="welcomeText"><span className="eyebrow">WELCOME TO YOUR WORLD</span><h1>Make this life <em>legendary.</em></h1><p>Every choice takes you somewhere. Start small, dream big, and build the life you want.</p><button className="primary" onClick={()=>setPage('work')}>Start a career <ChevronRight size={17}/></button></div><div className="bannerOrb"><Globe2 size={110}/><span className="orbTag">NG ↔ US</span></div></div><div className="statsGrid"><Stat icon={<Wallet/>} label="Cash in hand" value={money(user.cash,user.country)} sub="Available to spend"/><Stat icon={<CreditCard/>} label="Bank balance" value={money(user.bank,user.country)} sub="Your savings"/><Stat icon={<BriefcaseBusiness/>} label="Current career" value={user.job} sub="Work to earn more"/><Stat icon={<Sparkles/>} label="Player level" value={`Level ${user.level}`} sub="Keep progressing"/></div><div className="sectionHead"><div><span className="eyebrow">YOUR WORLD</span><h3>Where do you want to go?</h3></div></div><div className="featureGrid">{[['game','Explore 3D City','Walk around a simple GTA-inspired city.','game'],['phone','World Phone','Messages, contacts and your social life.','phone'],['work','Find a job','Earn in-game money and build your career.','work'],['building','Find a home','Choose a place to call your own.','building'],['car','Get a vehicle','Explore your city in style.','car'],['bank','Manage money','Save cash and make withdrawals.','bank'],['travel','Travel abroad','Explore the other country server.','travel']].map(([ic,t,d,p])=><button className="featureCard" key={t} onClick={()=>setPage(p)}><div className="featureIcon"><Icon name={ic} size={22}/></div><div><h4>{t}</h4><p>{d}</p></div><ChevronRight className="featureArrow"/></button>)}</div><div className="sectionHead"><div><span className="eyebrow">PLAYER PROFILE</span><h3>Your current life</h3></div></div><div className="profileStrip"><div><MapPin/><span><small>Location</small><b>{user.city}, {user.state}</b></span></div><div><BriefcaseBusiness/><span><small>Career</small><b>{user.job}</b></span></div><div><House/><span><small>Home</small><b>{user.home}</b></span></div><div><CarFront/><span><small>Transport</small><b>{user.car}</b></span></div></div></>}
 {page==='phone'&&<div className="phoneLayout"><div className="phoneIntro"><span className="eyebrow">YOUR POCKET WORLD</span><h1>Meet your <em>World Phone.</em></h1><p>One place for your conversations, community updates and everyday life.</p><div className="phoneFrame"><div className="phoneNotch"/><div className="phoneStatus">9:41 <span>●●● 5G ▰</span></div><div className="phoneBrand"><Globe2/> WORLD PHONE <span>4K</span></div><div className="phoneGreeting">Hello, {user.username} 👋<small>{user.city}, {user.country}</small></div><div className="phoneApps">{[['chat','Messages'],['social','Social'],['people','Friends'],['explore','Maps'],['bank','Wallet'],['travel','Travel'],['shop','Shop'],['work','Jobs']].map(([ic,t])=><button key={t} onClick={()=>setPage(ic==='people'?'chat':ic==='explore'?'home':ic)}><Icon name={ic} size={22}/><small>{t}</small></button>)}</div><div className="phoneRecent"><b>Recent conversations</b>{messages.slice(-3).reverse().map(m=><div key={m.id}><span className="tinyAvatar">{m.username[0]}</span><span>{m.username}<small>{m.text}</small></span></div>)}{!messages.length&&<p>No chats yet. Say hello to the world.</p>}</div><button className="phoneOpen" onClick={()=>setPage('chat')}>Open messages <ChevronRight size={15}/></button></div></div><div className="phoneFeatures"><h2>Everything in one place</h2>{[['chat','Messages','Send messages to other players.'],['social','Social feed','Share updates with the community.'],['bank','Wallet','Keep track of your in-game money.'],['travel','Travel','Plan trips between country servers.'],['work','Career','See your job and earnings.']].map(([ic,t,d])=><div className="phoneFeature" key={t}><div className="featureIcon"><Icon name={ic}/></div><div><b>{t}</b><p>{d}</p></div></div>)}</div></div>}
 {page==='chat'&&<div className="chatPanel"><div className="panelHeading"><div><span className="eyebrow">WORLD PHONE</span><h3>Global messages</h3><p>Messages are shared with signed-in players on this prototype.</p></div><div className="onlinePill"><span className="liveDot"/> Live connection</div></div><div className="chatMessages">{messages.map(m=><div key={m.id} className={`chatBubble ${m.userId===user.id?'mine':''}`}><div className="bubbleMeta">{m.username} · {m.country}</div><p>{m.text}</p><small>{new Date(m.createdAt).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</small></div>)}{!messages.length&&<div className="emptyState"><MessageCircle size={34}/><h3>Your conversations start here</h3><p>Send the first message to the world.</p></div>}</div><form className="chatComposer" onSubmit={e=>{e.preventDefault();sendMessage()}}><input placeholder="Write a message to the world…" value={message} onChange={e=>setMessage(e.target.value)} maxLength={500}/><button className="primary" disabled={busy||!message.trim()}><Send size={18}/><span>Send</span></button></form></div>}
 {page==='social'&&<div className="twoCol"><div className="panel"><span className="eyebrow">COMMUNITY</span><h3>Share your story</h3><form onSubmit={e=>{e.preventDefault();publish()}}><textarea placeholder="What's happening in your world?" value={postText} onChange={e=>setPostText(e.target.value)} maxLength={500}/><div className="composerBottom"><small>{postText.length}/500</small><button className="primary" disabled={busy||!postText.trim()}>Publish post</button></div></form></div><div className="feedList">{posts.map(p=><article className="feedPost" key={p.id}><div className="postHeader"><div className="avatar">{p.username[0]}</div><div><b>{p.username}</b><small>{p.city||p.country||'World citizen'} · {new Date(p.createdAt).toLocaleString()}</small></div></div><p>{p.text}</p><div className="postFoot"><Heart size={16}/> Community update</div></article>)}{!posts.length&&<div className="emptyState"><Newspaper/><h3>Your feed is waiting</h3><p>Share the first update.</p></div>}</div></div>}
 {page==='work'&&<><div className="pageIntro"><span className="eyebrow">CAREER & PROGRESSION</span><h1>Earn your next <em>opportunity.</em></h1><p>Choose a job and complete a shift to earn simulated game currency.</p></div><div className="jobGrid">{[['Delivery Rider','1,800','Fast deliveries across the city.'],['Shop Assistant','2,200','Help customers and keep business moving.'],['Software Developer','5,000','Build digital tools for the modern world.'],['Taxi Driver','2,500','Take people where they need to go.'],['Real Estate Agent','3,500','Help residents find a home.'],['Security Officer','2,000','Help keep your neighbourhood safe.']].map(([t,p,d])=><button key={t} className={`jobCard ${job===t?'jobSelected':''}`} onClick={()=>setJob(t)}><div className="featureIcon"><BriefcaseBusiness/></div><h3>{t}</h3><p>{d}</p><div className="jobPay">+{p} <small>per shift*</small></div><span className="selectMark">{job===t?'Selected':'Select job'}</span></button>)}</div><div className="actionBar"><p>*Illustrative in-game rewards, not real wages.</p><button className="primary" onClick={work} disabled={busy}>Complete work shift <ChevronRight size={18}/></button></div></>}
 {page==='building'&&<><div className="pageIntro"><span className="eyebrow">PROPERTY MARKET</span><h1>Find a place to <em>call home.</em></h1><p>Buy a home using your in-game cash.</p></div><div className="listingGrid">{market.filter(i=>i.category==='Property').map(i=><Listing key={i.id} item={i} user={user} onBuy={buy} busy={busy}/>)}</div><div className="noticePanel"><House/><div><b>Your current home</b><p>{user.home}</p></div></div></>}
 {page==='car'&&<><div className="pageIntro"><span className="eyebrow">VEHICLE DEALERSHIP</span><h1>Find your next <em>ride.</em></h1><p>Purchase a vehicle to update your player profile.</p></div><div className="listingGrid">{market.filter(i=>i.category==='Vehicles').map(i=><Listing key={i.id} item={i} user={user} onBuy={buy} busy={busy}/>)}</div><div className="noticePanel"><CarFront/><div><b>Your current transport</b><p>{user.car}</p></div></div></>}
 {page==='shop'&&<><div className="pageIntro"><span className="eyebrow">WORLD MARKETPLACE</span><h1>Make your world <em>your own.</em></h1><p>Starter marketplace with simulated purchases for homes and vehicles.</p></div><div className="listingGrid">{market.map(i=><Listing key={i.id} item={i} user={user} onBuy={buy} busy={busy}/>)}</div><div className="noticePanel"><ShieldCheck/><div><b>Safe prototype purchases</b><p>These transactions use game cash only. No real money is charged.</p></div></div></>}
 {page==='bank'&&<><div className="bankHero"><div><span className="eyebrow">WORLD BANK</span><h1>Money management, <em>made simple.</em></h1><p>Move your in-game money between cash and savings.</p></div><Wallet size={64}/></div><div className="statsGrid bankStats"><Stat icon={<Wallet/>} label="Cash balance" value={money(user.cash,user.country)} sub="Available now"/><Stat icon={<CreditCard/>} label="Savings balance" value={money(user.bank,user.country)} sub="In-game bank"/></div><div className="bankActions"><div className="panel"><div className="featureIcon"><ArrowDownToLine/></div><h3>Deposit cash</h3><p>Move money from your pocket into savings.</p><label>Amount<input type="number" min="1" step="1" value={amount} onChange={e=>setAmount(e.target.value)}/></label><button className="primary full" onClick={()=>bank('deposit')} disabled={busy}>Deposit funds</button></div><div className="panel"><div className="featureIcon"><ArrowUpFromLine/></div><h3>Withdraw savings</h3><p>Move savings back to your cash balance.</p><label>Amount<input type="number" min="1" step="1" value={amount} onChange={e=>setAmount(e.target.value)}/></label><button className="secondary full" onClick={()=>bank('withdraw')} disabled={busy}>Withdraw funds</button></div></div><div className="noticePanel"><ShieldCheck/><div><b>In-game banking only</b><p>This is a simulated game economy, not a real bank account or financial service.</p></div></div></>}
 {page==='travel'&&<><div className="pageIntro"><span className="eyebrow">INTERNATIONAL CONNECTIONS</span><h1>Two countries. <em>One world.</em></h1><p>Start on your selected server and plan a journey to the other country.</p></div><div className="travelRoute"><div className="travelCountry"><span>{user.country==='Nigeria'?'🇳🇬':'🇺🇸'}</span><small>DEPARTURE</small><h3>{user.country}</h3><p>{user.city}, {user.state}</p></div><div className="routeLine"><Plane/><div/></div><div className="travelCountry"><span>{travelTo==='Nigeria'?'🇳🇬':'🇺🇸'}</span><small>DESTINATION</small><h3>{travelTo}</h3><p>{travelTo==='Nigeria'?'Lagos, Abuja and more':'New York, Miami and more'}</p></div></div><div className="travelPurchase"><div><span className="eyebrow">INTERNATIONAL TRIP</span><h2>$5.00 <small>USD per trip</small></h2><p>Domestic movement is intended to use in-game money. Real-money checkout is not enabled in this foundation build.</p></div><div className="travelControls"><label>Travel to<select value={travelTo} onChange={e=>setTravelTo(e.target.value)}><option>Nigeria</option><option>USA</option></select></label><button className="primary" onClick={travel} disabled={busy||travelTo===user.country}>Check trip</button></div></div><div className="noticePanel"><ShieldCheck/><div><b>Payment safety</b><p>No real-money payment has been taken. A verified payment provider and server-side confirmation must be integrated before charging $5.</p></div></div></>}
 {page==='people'&&<><div className="pageIntro"><span className="eyebrow">WORLD COMMUNITY</span><h1>Meet the <em>people of your world.</em></h1><p>Chat and social feed features are available in this foundation build.</p></div><div className="communityCards"><button className="featureCard" onClick={()=>setPage('chat')}><div className="featureIcon"><MessageCircle/></div><div><h4>Global chat</h4><p>Send messages to signed-in players.</p></div><ChevronRight/></button><button className="featureCard" onClick={()=>setPage('social')}><div className="featureIcon"><Newspaper/></div><div><h4>Community feed</h4><p>Post an update and see community posts.</p></div><ChevronRight/></button></div><div className="noticePanel"><Users/><div><b>Multiplayer status</b><p>Live messaging is connected. Shared 3D avatars, voice/video calls, player presence and a synchronized open world still require further development.</p></div></div></>}
 <footer className="footer"><span>© 2026 WORLD LIFE 4K</span><span>Prototype foundation · Game currency has no real-world value</span></footer>
 </section></main></div>
}
function Stat({icon,label,value,sub}){return <div className="statCard"><div className="statTop">{icon}<span>{label}</span></div><strong>{value}</strong><small>{sub}</small></div>}
function Listing({item,user,onBuy,busy}){return <article className="listingCard"><div className="listingArt"><Icon name={item.category==='Property'?'building':'car'} size={46}/><span>{item.category}</span></div><div className="listingInfo"><h3>{item.title}</h3><p>Available in the {user.country} world</p><div className="listingBottom"><strong>{money(item.price,user.country)}</strong><button className="primary" onClick={()=>onBuy(item.title)} disabled={busy||user.cash<item.price}>Buy</button></div></div></article>}
createRoot(document.getElementById('root')).render(<App/>);
